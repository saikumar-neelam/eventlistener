package main

import (
	"fmt"
	"github.com/hyperledger/fabric-config/protolator"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/event"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/msp"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/providers/fab"
	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/fab/events/deliverclient/seek"
	"github.com/hyperledger/fabric-sdk-go/pkg/fabsdk"
	//	"os"
	"bytes"
	"encoding/base64"
	"encoding/json"
	//"math"
	"reflect"
	"strconv"
	"time"
)

const (
	channelID = "preferences"
	orgName   = "ETISALAT"
)

func enrollUser(sdk *fabsdk.FabricSDK) {
	user := "admin"
	ctx := sdk.Context()
	mspClient, err := msp.New(ctx)
	if err != nil {
		fmt.Printf("Failed to create msp client: %s\n", err)
	}
	_, err = mspClient.GetSigningIdentity("admin")

	fmt.Println(">>>>>>>>>>>>>>>>>>>>>>", err, "<<<<<<<<<<<<<<<<<", msp.ErrUserNotFound)

	if err == msp.ErrUserNotFound {
		fmt.Println("Going to enroll user")
		err = mspClient.Enroll("admin", msp.WithSecret("adminpw"))
		if err != nil {
			fmt.Printf("Failed to enroll user: %s\n", err)
		} else {
			fmt.Printf("Success enroll user: %s\n", user)
		}
	} else if err != nil {
		fmt.Printf("Failed to get user: %s\n", err)
	} else {
		fmt.Printf("User %s already enrolled, skip enrollment.\n", user)
	}
}

func GenerateKeysFromJson(m map[string]interface{}) []string {
	keys := make([]string, len(m))
	i := 0
	for k := range m {
		keys[i] = k
		i++
	}
	return keys
}

func eventResult(notifier <-chan *fab.BlockEvent) error {
	select {
	case blockEvent := <-notifier:
		//fmt.Println(blockEvent.Block.Data)
		var buffer bytes.Buffer
		err := protolator.DeepMarshalJSON(&buffer, blockEvent.Block.Data)
		if err != nil {
			fmt.Printf("  Error pretty printing block: %s", err)
		}
		fmt.Println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
		block := buffer.String()
		var result map[string]interface{}
		err = json.Unmarshal([]byte(block), &result)
		if err != nil {
			fmt.Println(err.Error())
		}
		fmt.Println("BlockNumber =[" + strconv.FormatUint(blockEvent.Block.Header.Number, 10) + "]")
		fmt.Println(blockEvent.Block.Metadata.Metadata[2][0])
		//fmt.Println(result)
		fmt.Println(GenerateKeysFromJson(result))
		//fmt.Println(reflect.TypeOf(buffer.String())
		//fmt.Println(reflect.TypeOf(result["data"]))
		root := result["data"].([]interface{})
		//fmt.Println(root)
		fmt.Println(BlockDataParsing(root))
		fmt.Println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
	case <-time.After(time.Second * 5):

		fmt.Errorf("Error ")
		fmt.Println("timeout while waiting for chaincode event")
	}
	return nil
}

func BlockDataParsing(root []interface{}) bool {
	for _, val := range root {
		data, _ := val.(map[string]interface{})
		//fmt.Println(Generate_Keys_From_Map(data)) //[payload signature]
		payload, _ := data["payload"].(map[string]interface{})
		//fmt.Println(Generate_Keys_From_Map(payload))//[header data]
		data1, _ := payload["data"].(map[string]interface{})
		//fmt.Println(Generate_Keys_From_Map(data1))//[actions]
		array, ok := data1["actions"].([]interface{})
		if !ok {
			fmt.Println("Error in []interface")
		}
		for _, val1 := range array {
			data2, _ := val1.(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(data2))//[header payload]
			invokermsp, _ := data2["header"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(invokermsp))//[creator,nonce]
			creator, _ := invokermsp["creator"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(creator))//[id_bytes,mspid]
			mspid := creator["mspid"].(string)
			fmt.Println(mspid)
			data3, _ := data2["payload"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(data3))//[chaincode_proposal_payload action]
			data4, _ := data3["action"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(data4))//[proposal_response_payload endorsements]
			data5, _ := data4["proposal_response_payload"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(data5))//[proposal_hash extension]
			data6, _ := data5["extension"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(data6))//[token_expectation results events response chaincode_id]
			evt, _ := data6["events"].(map[string]interface{})
			//fmt.Println(Generate_Keys_From_Map(evt))//[event_name payload chaincode_id tx_id]

			//fmt.Println(evt)//map[]
			if len(evt) == 0 {
				fmt.Println("No Custom Events")
			} else {
				if evt["event_name"] == "ADD_PREFERENCES" || evt["event_name"] == "UPDATE_PREFERENCES" || evt["event_name"] == "PORT_OUT" || evt["event_name"] == "DELETE_PREFERENCES" || evt["event_name"] == "SNAP_BACK_CHURN" {
					fmt.Println("EventName is [" + string(evt["event_name"].(string)) + "] and TransactionId is [" + string(evt["tx_id"].(string)) + "]")
					//fmt.Println(evt["payload"].(string))
					data7, _ := data6["results"].(map[string]interface{})
					//fmt.Println(Generate_Keys_From_Map(data7))//[ns_rwset data_model]
					array1, ok1 := data7["ns_rwset"].([]interface{})
					if !ok1 {
						fmt.Println("Error in []interface 1")
					}
					for _, val2 := range array1 {
						data8, _ := val2.(map[string]interface{})
						//fmt.Println(Generate_Keys_From_Map(data8))//[namespace rwset collection_hashed_rwset]
						data9, _ := data8["rwset"].(map[string]interface{})
						//fmt.Println(Generate_Keys_From_Map(data9))//[metadata_writes reads range_queries_info writes]
						array2, ok2 := data9["writes"].([]interface{})
						if !ok2 {
							fmt.Println("Error in []interface 2")
						}

						for _, val3 := range array2 {
							data10, _ := val3.(map[string]interface{})
							//fmt.Println(Generate_Keys_From_Map(data10))//[key is_delete value]
							//fmt.Println(data10["value"].(string))
							data, err := base64.StdEncoding.DecodeString(data10["value"].(string))
							if err != nil {
								fmt.Println("Decoding Error is :" + string(err.Error()))
							}
							fmt.Println(string(data))
							//fmt.Println(len(txid))
						}
					}
				}
			}
		}
	}
	return true
}

func read_block_events(client *event.Client) {
	reg, notifier, err := client.RegisterBlockEvent()

	if err != nil {
		fmt.Println("Register BlockEvent Error is " + string(err.Error()))
	}
	defer client.Unregister(reg)
	for {
		eventResult(notifier)
	}
}

func main() {
	configPath := "/DISK01/arun/ETISALAT_MODULES/EVENT-TEST/V3/connection-profile.yaml"
	configOpt := config.FromFile(configPath)
	sdk, err := fabsdk.New(configOpt)
	if err != nil {
		fmt.Println("fabsdk new error is [{}]" + string(err.Error()))
	}
	fmt.Println(sdk)
	defer sdk.Close()
	enrollUser(sdk)
	clientChannelContext := sdk.ChannelContext(channelID, fabsdk.WithUser("admin"), fabsdk.WithOrg(orgName))
	fmt.Println(reflect.TypeOf(clientChannelContext))
	client, err := event.New(clientChannelContext, event.WithBlockEvents(), event.WithSeekType(seek.FromBlock), event.WithBlockNum(260))
	if err != nil {
		fmt.Println("unable to get event service : %s", err)
	}
	read_block_events(client)

}
